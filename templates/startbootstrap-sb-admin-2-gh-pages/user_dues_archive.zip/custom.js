$('#st').click(function(){
    alert("Working");
});