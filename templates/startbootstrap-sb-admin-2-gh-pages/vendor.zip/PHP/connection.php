<?php
session_start();

$con=mysqli_connect("localhost","root","","library_management")or 
die("Couldn't connect to server");
?>